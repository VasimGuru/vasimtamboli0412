import React from "react";

const EditUser = () => {
  return (
    <>
      <h1>Add user</h1>
    </>
  );
};

export default EditUser;
